<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/styleslogin.css">
    <style>
       #mensagem{

            padding: 4px;
            color:rgba(196, 28, 28, 0.92) ;
        }


    </style>

</head>
<body>
<?php

        session_start();
        $mensagemacerto="";
        // Acessar a variável de sessão
        if (isset($_SESSION['deubom'])) {

            if($_SESSION['deubom']=='positivo'){
                $mensagemacerto= "Cadastro deu bom";
            }    
        }    
        
            $texto="";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (isset($_POST['botaosubmit'])) {
        
                session_start(); // Inicia a sessão

                $servername = "localhost";
                $username = "root"; 
                $password = ""; 
                $dbname = "sistema_login";
                

                $conn = new mysqli($servername, $username, $password, $dbname);

                if ($conn->connect_error) {
                    die("Falha na conexão: " . $conn->connect_error);
                }

                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $email = $_POST['email'];
                    $senha = $_POST['senha'];

                    // Ver se o email existe no banco de dados
                    $sql = "SELECT * FROM usuarios WHERE email = '$email'";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Se o usuário for encontrado, recupera seus dados
                        $usuario = $result->fetch_assoc();

                        if (password_verify($senha, $usuario['senha'])) {
                            
                            $_SESSION['usuario_email'] = $usuario['email'];
                            $_SESSION['usuario_senha'] = $usuario['senha'];

                            header("Location: ../site.php"); 
                            exit();
                        } else {
                            $texto= "Senha incorreta!";
                        }
                    } else {
                        $texto= "Usuário não encontrado!";
                    }
                }
           
                 $conn->close();
                }
        }    
 ?>       

<div class="container">
<div id="mensagemdeubom"><?php echo  $mensagemacerto ?></div>    

<div class="form-container">
     <h2>Login de Usuário</h2>
        <form action="" method="POST">
            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <div class="input-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required>
                <div id="mensagem"><?php echo $texto; ?></div>
            </div>

            <button type="submit" name="botaosubmit">Entrar</button>
            <p>Ainda não tem uma conta? <a href="register.php">Cadastre-se aqui.</a></p>
        </form>
    </div>
</div>



</body>
</html>
