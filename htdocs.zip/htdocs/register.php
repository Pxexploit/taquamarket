<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuário</title>
    <link rel="stylesheet" href="css/stylesregister.css">

    <style>
       #mensagemerro{

            padding: 4px;
            color:rgba(196, 28, 28, 0.92) ;
        }


    </style>
</head>
<body>

            <?php
            
            $erro="";
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                if (isset($_POST['botaosubmit'])) {
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "sistema_login";


                        $conn = new mysqli($servername, $username, $password, $dbname);


                        if ($conn->connect_error) {
                            die("Conexão falhou: " . $conn->connect_error);
                        }


                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            $nome = $_POST['nome'];
                            $email = $_POST['email'];
                            $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT); 

                            // Verificar se o email já está registrado
                            $sql_check = "SELECT id FROM usuarios WHERE email = '$email'";
                            $result = $conn->query($sql_check);

                            if ($result->num_rows > 0) {
                                $erro= "Este email já está registrado!";
                            } else {

                                $sql = "INSERT INTO usuarios (nome, email, senha) VALUES ('$nome', '$email', '$senha')";

                                if ($conn->query($sql) === TRUE) {
                                    // cod para a página de login após o cadastro
                                    session_start();

                                     // Definir uma variável de sessão
                                    $_SESSION['deubom'] = 'positivo';
                                    header("Location: ../login.php");
                                    exit; 
                                } else {
                                    $erro= "Erro ao cadastrar usuário: " . $conn->error;
                                }
                            }
                        }

                        $conn->close();
                    }
                }         
            ?>


<div class="container">
    <div class="form-container">
        <h2>Cadastro de Usuário</h2>
        <form action="" method="POST">
            <div class="input-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" required>
            </div>
            
            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <div class="input-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required>
                <div id="mensagemerro"><?php echo $erro ?></div>
            </div>
            
            <button type="submit" name="botaosubmit">Cadastrar</button>
            <p>Já tem uma conta? <a href="login.php">Faça login aqui.</a></p>
        </form>
    </div>
</div>

</body>
</html>
