<?php
// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ação a ser realizada após o envio do formulário
    $nome = $_POST['nome'];
    echo "<p>Olá, $nome! Seu formulário foi enviado com sucesso.</p>";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exemplo de Formulário com PHP</title>
</head>
<body>
    <h2>Formulário de Nome</h2>
    
    <!-- Formulário que envia dados para a mesma página -->
    <form method="POST" action="">
        <label for="nome">Digite seu nome:</label>
        <input type="text" id="nome" name="nome" required>
        <button type="submit">Enviar</button>
    </form>
</body>
</html>
