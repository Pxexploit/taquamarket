<?php
// Conectar ao banco de dados
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "sistema_login"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Inserção de dados de produtos
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome_produto = $_POST['nome_produto'];
    $descricao_produto = $_POST['descricao_produto'];
    $preco_produto = $_POST['preco_produto'];
    
    // Infos dos vendedores
    $email_vendedor = $_POST['email_vendedor'];
    $nome_loja = $_POST['nome_loja'];
    $nome_vendedor = $_POST['nome_vendedor'];

    $imagem_produto = $_FILES['imagem_produto']['name'];
    $target_dir = "uploads/"; // pasta onde as imagens serão salvas
    $target_file = $target_dir . basename($imagem_produto);

    if (move_uploaded_file($_FILES['imagem_produto']['tmp_name'], $target_file)) {
        // Inserir dados no banco de dados
        $sql = "INSERT INTO produtos (nome_produto, descricao_produto, preco_produto, imagem_produto, email_vendedor, nome_loja, nome_vendedor) 
                VALUES ('$nome_produto', '$descricao_produto', '$preco_produto', '$imagem_produto', '$email_vendedor', '$nome_loja', '$nome_vendedor')";

        if ($conn->query($sql) === TRUE) {
            header('Location: produtos.php');
            exit; 
        } else {
            echo "Erro ao cadastrar produto: " . $conn->error;
        }
    } else {
        echo "Erro ao enviar a imagem.";
    }
}

// Buscar produtos do banco de dados
$sql_produtos = "SELECT * FROM produtos";
$result = $conn->query($sql_produtos);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace - Produtos</title>
    <link rel="stylesheet" href="css/telaproduto.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="logo"><img src="images/site2.png" alt="" style="width: 4.7rem;"></div>
        <div class="search-bar">
            <input type="text" placeholder="Buscar produtos...">
        </div>
        <div class="filters">
            <button>Filtros</button>
        </div>
    </header>

    <!-- Filtros de Pesquisa -->
    <div class="filters-section">
        <select name="category" id="category">
            <option value="todos">Todas as Categorias</option>
            <option value="eletronicos">Eletrônicos</option>
            <option value="roupas">Roupas</option>
            <option value="moveis">Móveis</option>
        </select>

        <input type="number" placeholder="Preço mínimo" id="min-price">
        <input type="number" placeholder="Preço máximo" id="max-price">

        <button>Aplicar Filtros</button>
    </div>

    <!-- Lista de Produtos -->
    <section class="product-list">
        <?php
        if ($result->num_rows > 0) {
            while($produto = $result->fetch_assoc()) {
                ?>
                <div class="product-card">
                    <img src="uploads/<?php echo $produto['imagem_produto']; ?>" alt="<?php echo $produto['nome_produto']; ?>">
                    <div class="product-details">
                        <h3 class="product-name"><?php echo $produto['nome_produto']; ?></h3>
                        <p class="product-description"><?php echo $produto['descricao_produto']; ?></p>
                        <span class="product-price">R$ <?php echo number_format($produto['preco_produto'], 2, ',', '.'); ?></span>
                        <br>
                        <span class="product-store">Loja: <?php echo $produto['nome_loja']; ?></span>
                        <span class="product-seller">Vendedor: <?php echo $produto['nome_vendedor']; ?></span>
                        <a href="mailto:<?php echo $produto['email_vendedor']; ?>" class="contact-button">Contato com o Vendedor</a>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<p>Nenhum produto encontrado.</p>";
        }
        ?>
    </section>

    <!-- Rodapé -->
    <footer>
        <div class="footer-links">
            <a href="/sobre">Sobre</a>
            <a href="/politica-privacidade">Política de Privacidade</a>
            <a href="/termos-uso">Termos de Uso</a>
        </div>
        <div class="footer-info">
            <p>© 2025 Meu Marketplace. Todos os direitos reservados.</p>
        </div>
    </footer>

</body>
</html>

<?php
// Fechar a conexão com o banco
$conn->close();
?>
