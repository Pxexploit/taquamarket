<?php
session_start();

if (isset($_SESSION['usuario_email']) && isset($_SESSION['usuario_senha']) && isset($_SESSION['usuario_tipo']) && $_SESSION['usuario_tipo'] == 'vendedor') {


    if (isset($_POST['cadastrar_produto'])) {
        $nome_produto = $_POST['nome_produto'];
        $descricao_produto = $_POST['descricao_produto'];
        $preco = $_POST['preco'];

        $conn = new mysqli("localhost", "root", "", "sistema_login");

        if ($conn->connect_error) {
            die("Conexão falhou: " . $conn->connect_error);
        }

       
        $id_vendedor = $_SESSION['usuario_id']; 
        $sql_loja = "SELECT id FROM lojas WHERE id_vendedor = '$id_vendedor' LIMIT 1";
        $result = $conn->query($sql_loja);
        if ($result->num_rows > 0) {
            $loja = $result->fetch_assoc();
            $id_loja = $loja['id'];
            
      
            $sql_produto = "INSERT INTO produtos (id_vendedor, id_loja, nome_produto, descricao, preco) 
                            VALUES ('$id_vendedor', '$id_loja', '$nome_produto', '$descricao_produto', '$preco')";
            
            if ($conn->query($sql_produto) === TRUE) {
                echo "Produto cadastrado com sucesso!";
            } else {
                echo "Erro ao cadastrar produto: " . $conn->error;
            }
        } else {
            echo "Você precisa cadastrar sua loja antes de adicionar produtos.";
        }

        $conn->close();
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Produto</title>
    <link rel="stylesheet" href="css/styles.css"> 
</head>
<body>

<header>
    <h1>Cadastrar Produto</h1>
    <a href="logout.php">Logout</a>
</header>

<section>
    <form action="cadastro_produto.php" method="POST">
        <label for="nome_produto">Nome do Produto:</label>
        <input type="text" id="nome_produto" name="nome_produto" required>
        
        <label for="descricao_produto">Descrição do Produto:</label>
        <textarea id="descricao_produto" name="descricao_produto" required></textarea>
        
        <label for="preco">Preço:</label>
        <input type="number" id="preco" name="preco" required>
        
        <button type="submit" name="cadastrar_produto">Cadastrar Produto</button>
    </form>
</section>

</body>
</html>
<?php
} else {
    echo "Você precisa estar logado como vendedor para acessar esta página.";
}
?>
